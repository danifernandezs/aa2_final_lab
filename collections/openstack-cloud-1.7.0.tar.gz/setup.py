# Copyright Red Hat, Inc. All Rights Reserved.
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

import setuptools

setuptools.setup(
    setup_requires=['pbr'],
    pbr=True)
